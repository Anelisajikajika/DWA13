import {
    products, filteredProducts, filteredAndMapped,totalPrice, concatenatedNames,
    highest, lowest, recreatedProducts
} from "./products.js";

const provinces = ['Western Cape', 'Gauteng', 'Northern Cape', 'Eastern Cape', 'KwaZulu-Natal', 'Free State']
const names = ['Ashwin', 'Sibongile', 'Jan-Hendrik', 'Sifso', 'Shailen', 'Frikkie']


names.forEach((name) => {
    console.log(name);
});

names.forEach((name, index) => {
    console.log(`${name} (${provinces[index]})`);
});

const uppercaseProvinces = provinces.map((province) => province.toUpperCase());
console.log(uppercaseProvinces);


const characterCountArray = names.map((name) => name.length);
console.log(characterCountArray);


const sortedProvinces = provinces.sort();
console.log(sortedProvinces);


const filteredProvinces = provinces.filter((province) => !province.includes("Cape"));
console.log(filteredProvinces);
console.log(`Number of provinces left: ${filteredProvinces.length}`);

const containsSArray = names.map((name) => name.split('').some((char) => char === 'S'));
console.log(containsSArray);

const provinceObject = names.reduce((acc, name, index) => {
    acc[name] = provinces[index];
    return acc;
}, {});
console.log(provinceObject);











