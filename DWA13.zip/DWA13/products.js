export const products = [
    { product: 'banana', price: "2" },
    { product: 'mango', price: 6 },
    { product: 'potato', price: ' ' },
    { product: 'avocado', price: "8" },
    { product: 'coffee', price: 10 },
    { product: 'tea', price: '' },
  
  ];

  products.forEach((product) => {
    console.log(product.product);
  });

 export const filteredProducts = products.filter((product) => product.product.length <= 5);

 export const filteredAndMapped = products
  .filter((product) => !isNaN(parseFloat(product.price)))
  .map((product) => ({ ...product, price: parseFloat(product.price) }));

export const totalPrice = filteredAndMapped.reduce((acc, product) => acc + product.price, 0);

export const concatenatedNames = products.reduce((acc, product, index, array) => {
    if (index === array.length - 1) {
      return acc + "and " + product.product;
    }
    return acc + product.product + ", ";
  }, "");
  
  console.log(concatenatedNames);
  
  export const { highest, lowest } = products.reduce(
    (acc, product) => {
      if (parseFloat(product.price) > acc.highest.price) {
        acc.highest = { name: product.product, price: parseFloat(product.price) };
      }
      if (parseFloat(product.price) < acc.lowest.price) {
        acc.lowest = { name: product.product, price: parseFloat(product.price) };
      }
      return acc;
    },
    { highest: { name: '', price: -Infinity }, lowest: { name: '', price: Infinity } }
  );
  
  console.log(`Highest: ${highest.name}. Lowest: ${lowest.name}`);

  export const recreatedProducts = products.reduce((acc, product) => {
    const modifiedProduct = Object.entries(product).reduce((productAcc, [key, value]) => {
      if (key === 'product') {
        productAcc.name = value;
      } else if (key === 'price') {
        productAcc.cost = value;
      } else {
        productAcc[key] = value;
      }
      return productAcc;
    }, {});
    acc.push(modifiedProduct);
    return acc;
  }, []);
  
  console.log(recreatedProducts);
  